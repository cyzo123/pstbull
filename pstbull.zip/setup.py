#!/usr/bin/env python3

import setuptools
import platform
import os
import zipfile
import urllib.request


def unzip(dir_file, dir_save):
    with zipfile.ZipFile(dir_file, 'r') as zip_ref:
        zip_ref.extractall(dir_save)

def linux():
  cwd = os.getcwd()
  os.system('mkdir /opt/pstbull/')
  os.chdir('/opt/pstbull/')
  url="https://raw.githubusercontent.com/cyzo123/pstbull/main/pstbull.zip"
  filename, headers = urllib.request.urlretrieve(url, filename="pstbull.zip")
  unzip("pstbull.zip")
  setuptools.setup(
      name="some_utils",
      version="1.1",
      packages=setuptools.find_packages(),
      entry_points={
          'console_scripts': [
              'pstbull = main:main',
          ],
      },
      include_package_data=True,
      )
  os.chdir(cwd)

def windows():
  cwd = os.getcwd()
  os.system('mkdir "C:\\Program Files\\PstBull\\"')
  os.chdir('C:\\Program Files\\PstBull\\')
  url="https://raw.githubusercontent.com/cyzo123/pstbull/main/pstbull.zip"
  filename, headers = urllib.request.urlretrieve(url, filename="pstbull.zip")
  unzip("pstbull.zip")
  setuptools.setup(
    name="some_utils",
    version="1.1",
    packages=setuptools.find_packages(),
    entry_points={
        'console_scripts': [
            'pstbull = main:main',
        ],
    },
    include_package_data=True,
    )
  os.chdir(cwd)

if platform.system()=="Linux":
  linux()
elif platform.system()=="Windows":
  windows()
else:
  print("[-]This tool is not supported for your operating system.")